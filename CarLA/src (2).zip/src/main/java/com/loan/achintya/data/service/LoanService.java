package com.loan.achintya.data.service;

import com.loan.achintya.data.model.EMI;

public interface LoanService {

	
	public EMI emiCalculate(EMI emi);

	

}
