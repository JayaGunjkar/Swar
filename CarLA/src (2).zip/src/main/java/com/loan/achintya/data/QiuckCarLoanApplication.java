package com.loan.achintya.data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QiuckCarLoanApplication {

	public static void main(String[] args) {
		SpringApplication.run(QiuckCarLoanApplication.class, args);
	System.out.println("run successfully");
	}

}
