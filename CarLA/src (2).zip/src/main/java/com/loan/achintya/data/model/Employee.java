package com.loan.achintya.data.model;
//package com.loan.achintya.data.model;
//
//import javax.persistence.Entity;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@Entity
//@NoArgsConstructor
//@AllArgsConstructor
//public class Employee {
//
//	private String EmployeeName;
//		
//}
