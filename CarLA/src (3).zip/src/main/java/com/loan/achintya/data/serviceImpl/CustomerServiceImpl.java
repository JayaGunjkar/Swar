package com.loan.achintya.data.serviceImpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loan.achintya.data.model.Customer;
import com.loan.achintya.data.model.SanctionDetails;
import com.loan.achintya.data.repository.CustomerRepository;
import com.loan.achintya.data.repository.SanctionRepo;
import com.loan.achintya.data.service.CustomerService;


@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	
	CustomerRepository cr;
	@Autowired
	SanctionRepo sr;
	
	
	@Override
	public Customer saveCustomer(Customer cust) {
		
		return cr.save(cust);
	}

	@Override
	public List<Customer> getAllCustomer() {
		
		return cr.findAll();
		
	}

	@Override
	public Customer getByid(int custId) {
		
		Optional<Customer> op=cr.findById(custId);
		if(op.isPresent()) {
			Customer cus=op.get();
			cus.getLoanDetails().setLoanStatus("VERIFIED");
			return cr.save(cus);
		}
		else {
		
		return  null;
		}	}

	@Override
	public Optional<Customer> getByVerified(int custId) {
		//String loanstatus=c.getLoanDetails().getLoanStatus();;
		Optional<Customer> op=cr.findById(custId);
		if(op.isPresent()) {
			
			Customer cus=op.get();
			if(cus.getLoanDetails().getLoanStatus().equalsIgnoreCase("VERIFIED")) { 
			//cus.getLoanDetails().setLoanStatus("VERIFIED");
			return op;
			}else {
				return null;
			}

		}
		else {
		
		return  null;
		}
	}

	@Override
	public List<Customer> getAllVerifiedCustomer() {
		cr.findAll();
	List<Customer> l= cr.findAll();
	Iterator<Customer> itr=l.iterator();
	List<Customer> list=new ArrayList<>();
	while(itr.hasNext()) {
		Customer cus=itr.next();
		
		if(cus.getLoanDetails().getLoanStatus().equalsIgnoreCase("VERIFIED")) { 
			
			list.add(cus);
			
			}
	}

	System.out.println(l.size());
	
	System.out.println(list.size());
		
		return list;
	}

	@Override
	public Customer getCustByid(int custId) {
		Optional<Customer> op=cr.findById(custId);
		if(op.isPresent()) {
			Customer cus=op.get();
			return cus;
		}
		return null;
	}

	@Override
	public Customer saveSCust(Customer c) {
		
		return cr.save(c);
	}

}
